import "./App.css";
import React, { useState } from "react";
import UserData from "./Components/UserData";
import UserInput from "./Components/UserInput";
const App = () => {
  const [inputarr, setInputarr] = useState([]);

  const [editableUserData, setEditableUserData] = useState();

  const deleteHandle = (i) => {
    let newdataArr = [...inputarr];
    newdataArr.splice(i, 1);
    setInputarr(newdataArr);
  };

  const editHandle = (i) => {
    const extractedData = inputarr.filter(
      (data, index) => index === i && data
    )[0];
    setEditableUserData(extractedData);

    // let newdataArr=[...inputarr]
    // newdataArr.splice(i,1)
    // setInputarr(newdataArr)
  };

  return (
    <div className="App">
      <h1 className="text-3xl font-bold text-center my-4">React Test Task</h1>
      <UserInput
        setInputarr={setInputarr}
        inputarr={inputarr}
        editableUserData={editableUserData}
      />

      {inputarr.length !== 0 && (
        <UserData
          data={inputarr}
          deleteHandle={deleteHandle}
          editHandle={editHandle}
        />
      )}
    </div>
  );
};

export default App;
